from django.urls import path
from .views import StaticticsAPIView, StaticticsViewSet


app_name = 'api'


urlpatterns = [
    
    path('statistics/', StaticticsViewSet.as_view({'get': 'list'})),
    # path('user/<int:user_id>/lessons/',
    #      UserLessonsViewSet.as_view({'get': 'list'}),
    #      name='user_lessons'),
    # path('user/<int:user_id>/tutorial/<int:tutorial_id>/lessons/',
    #      UserTutorialLessonsViewSet.as_view({'get': 'list'}),
    #      name='user_tutorial_lessons'),

]
