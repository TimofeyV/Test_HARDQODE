from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.viewsets import GenericViewSet, ReadOnlyModelViewSet
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import OrderingFilter, SearchFilter
from rest_framework.permissions import AllowAny
from rest_framework.pagination import LimitOffsetPagination
from rest_framework.viewsets import GenericViewSet, ReadOnlyModelViewSet

from products.models import Product, Lesson
from backend.models import LessonViewing
from .serializers import ProductSerializer



class StaticticsAPIView(APIView):
    """Получение списка продуктов для текущего пользователя."""

    def get(self, request):
        p = Product.objects.all()
        return Response({'products': ProductSerializer(p, many=True).data})

class StaticticsViewSet(ReadOnlyModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    filter_backends = (DjangoFilterBackend, OrderingFilter, SearchFilter)
    filterset_fields = ('title', )
    search_fields = ('title', 'description')
    ordering_fields = ['id', 'title']
    pagination_class = LimitOffsetPagination
    permission_classes = (AllowAny, )
    



